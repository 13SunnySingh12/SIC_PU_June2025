Engineering Trend Analysis Tool

Setup Instructions: -

1. Install Python 3.8 or newer.

2. Open command prompt / terminal inside the folder.

3. Install dependencies:
   	
	pip install -r requirements.txt

4. Run the main_app.py:

   	python main_app.py

5. "Ctrl + click" on "http://127.0.0.1:5762"  to follow the link.

Make sure 'engineering_btech_trends_2019_2024.xlsx' is in the same folder as main_app.py.
