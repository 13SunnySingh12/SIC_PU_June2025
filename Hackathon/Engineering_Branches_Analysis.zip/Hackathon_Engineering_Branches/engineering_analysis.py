import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import uuid
import os

def load_data():
    try:
        df = pd.read_excel('engineering_btech_trends_2019_2024.xlsx')
        df.columns = df.columns.str.strip()
        df['Year'] = df['Year'].astype(int)
        sns.set(style="whitegrid")
        return df
    except Exception as e:
        print("Error loading data:", e)
        return None

def save_plot():
    filename = f"plot_{uuid.uuid4().hex}.png"
    path = os.path.join("static", filename)
    plt.savefig(path)
    plt.close()
    return filename

def show_highest_growth_trend(df):
    pivot_df = df.pivot(index='Year', columns='Branch', values='Enrollment').astype(int)
    growth = pivot_df.loc[df['Year'].max()] - pivot_df.loc[df['Year'].min()]
    top_branch = growth.idxmax()

    plt.figure(figsize=(12, 7))
    for branch in pivot_df.columns:
        if branch == top_branch:
            plt.plot(pivot_df.index, pivot_df[branch], marker='o', linestyle='--', linewidth=3,
                     label=f"{branch} (Highest Growth)", color='green')
        else:
            plt.plot(pivot_df.index, pivot_df[branch], marker='o', label=branch, alpha=0.6)

    plt.title(f"Engineering Branch Enrollment Trends ({df['Year'].min()}–{df['Year'].max()})", fontsize=14)
    plt.xlabel("Year")
    plt.ylabel("Enrollment Numbers")
    plt.grid(True)
    plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
    plt.ticklabel_format(style='plain', axis='y')
    plt.tight_layout()

    conclusion_text = (
        f"{top_branch} Engineering has shown the highest growth trend in recent years (2019–2024), indicating rising student interest and increasing industry relevance.\n"
        f"This growth suggests that {top_branch} is becoming a top choice among engineering aspirants, possibly due to evolving technological demands and attractive career opportunities in this domain."
    )

    filename = save_plot()
    return filename, conclusion_text

def show_most_demanded_branch(df):
    branch_demand = df.groupby("Branch")["Students Placed"].mean().reset_index()
    most_demand_branch = branch_demand.loc[branch_demand["Students Placed"].idxmax()]

    plt.figure(figsize=(12, 7))
    sns.barplot(data=branch_demand, x="Branch", y="Students Placed", palette='Greens')
    plt.title("Most Demanded Branch (2019–2024)", fontsize=16)
    plt.axhline(most_demand_branch["Students Placed"], color='black', linestyle='--',
                label=f"Most Demanded: {most_demand_branch['Branch']}")
    plt.xticks(rotation=45)
    plt.legend()
    plt.tight_layout()

    conclusion_text = (
        f"{most_demand_branch['Branch']} is currently the most in-demand engineering branch in the industry, with the highest number of student placements between 2019 and 2024.\n"
        f"Its clear lead in placement numbers indicates strong and growing industry demand, likely driven by the rise in tech-driven sectors, software roles, and digital transformation across industries."
    )

    filename = save_plot()
    return filename, conclusion_text

def show_least_demanded_branch(df):
    branch_demand = df.groupby("Branch")["Students Placed"].mean().reset_index()
    least_demand_branch = branch_demand.loc[branch_demand["Students Placed"].idxmin()]

    plt.figure(figsize=(12, 7))
    sns.barplot(data=branch_demand, x="Branch", y="Students Placed", palette='Reds')
    plt.title("Least Demanded Branch (2019–2024)", fontsize=16)
    plt.axhline(least_demand_branch["Students Placed"], color='black', linestyle='--',
                label=f"Least Demanded: {least_demand_branch['Branch']}")
    plt.xticks(rotation=45)
    plt.legend()
    plt.tight_layout()

    conclusion_text = (
        f"{least_demand_branch['Branch']} is currently facing the least demand in the industry based on placement data from 2019 to 2024.\n"
        f"Its low placement figures suggest limited opportunities and decreasing relevance in the job market."
    )

    filename = save_plot()
    return filename, conclusion_text

def show_declining_branch(df):
    df['Enrollment'] = pd.to_numeric(df['Enrollment'], errors='coerce').fillna(0).astype(int)
    pivot_df = df.pivot(index='Year', columns='Branch', values='Enrollment').sort_index()
    yearly_change = pivot_df.diff()
    negative_counts = (yearly_change < 0).sum()
    most_declining_branch = negative_counts.idxmax()

    plt.figure(figsize=(12, 7))
    for branch in pivot_df.columns:
        if branch == most_declining_branch:
            plt.plot(pivot_df.index, pivot_df[branch],
                     label=f"{branch} (Most Likely to Decline)", color='red', linewidth=3, linestyle='--', marker='o')
        else:
            plt.plot(pivot_df.index, pivot_df[branch], label=branch, linestyle='-', alpha=0.5)

    plt.title("Branch Most Likely to Decline", fontsize=14)
    plt.xlabel("Year")
    plt.ylabel("Enrollment Count")
    plt.grid(True)
    plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
    plt.ticklabel_format(style='plain', axis='y')
    plt.tight_layout()

    conclusion_text = (
        f"{most_declining_branch} Engineering has experienced the most consistent drop in enrollment from {df['Year'].min()} to {df['Year'].max()}.\n"
        f"This suggests a steady decline in popularity or demand for this branch in recent years."
    )

    filename = save_plot()
    return filename, conclusion_text
