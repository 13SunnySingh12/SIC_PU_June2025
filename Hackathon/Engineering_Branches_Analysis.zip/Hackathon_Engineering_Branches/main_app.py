from flask import Flask, render_template, url_for
import pandas as pd
import os
import glob

from engineering_analysis import (
    load_data,
    show_highest_growth_trend,
    show_most_demanded_branch,
    show_least_demanded_branch,
    show_declining_branch
)

app = Flask(__name__)

def cleanup_static_folder():
    """Delete old generated plots to avoid clutter."""
    for file in glob.glob("static/plot_*.png"):
        try:
            os.remove(file)
        except Exception as e:
            print(f"Error deleting file {file}: {e}")

@app.route('/')
def menu():
    return render_template('menu.html')

@app.route('/highest-growth')
def highest_growth():
    cleanup_static_folder()
    data = load_data()
    if data is None:
        return "Data loading failed.", 500
    image, conclusion = show_highest_growth_trend(data)
    return render_template('result.html', title="Highest Growth Branch", image=image, conclusion=conclusion)

@app.route('/most-demanded')
def most_demanded():
    cleanup_static_folder()
    data = load_data()
    if data is None:
        return "Data loading failed.", 500
    image, conclusion = show_most_demanded_branch(data)
    return render_template('result.html', title="Most Demanded Branch", image=image, conclusion=conclusion)

@app.route('/least-demanded')
def least_demanded():
    cleanup_static_folder()
    data = load_data()
    if data is None:
        return "Data loading failed.", 500
    image, conclusion = show_least_demanded_branch(data)
    return render_template('result.html', title="Least Demanded Branch", image=image, conclusion=conclusion)

@app.route('/declining')
def declining():
    cleanup_static_folder()
    data = load_data()
    if data is None:
        return "Data loading failed.", 500
    image, conclusion = show_declining_branch(data)
    return render_template('result.html', title="Branch Most Likely to Decline", image=image, conclusion=conclusion)

if __name__ == '__main__':
    cleanup_static_folder()
    app.run(debug=True, port=5762)
